Folder & File List:
Altium CAD\WBZ451 Curiosity Board-R7.zip: Contains the Altium Design Source Files for WBZ451 Curiosity Board
BOM\02-00307-R7_BOM.xls: Contains the Bill Of Materials for WBZ451 Curiosity Board
Gerber\05-00307-R4_PNP: Contains the pick and place files for WBZ451 Curiosity Board
Gerber\05-11423-R4: Contains the release gerber files for WBZ451 Curiosity Board
Gerber\04-11423-R4-D.pdf: Contains the Fab drawing for WBZ451 Curiosity Board
Gerber\04-11423-R4-PCB.pdf: Contains the PCB layer drawing for WBZ451 Curiosity Board
Gerber\05-00307-R4.pdf: Contains the Assembly drawings and 3D images for WBZ451 Curiosity Board
Schematics\03-00307-R7.pdf: Contains the Schematic drawing for WBZ451 Curiosity Board